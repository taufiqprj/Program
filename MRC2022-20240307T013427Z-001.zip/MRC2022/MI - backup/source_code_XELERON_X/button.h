void waitButton() {
  lcd.clear();
  delay(150);
  while (buttonPressed);
}
